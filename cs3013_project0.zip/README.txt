Project 0 - Sarayu Vijayanagaram

Section 1:
I used the browser-based VM to complete this assignment.

Section 3:
strncpy is associated with string.h.
printf is associated with stdio.h.
exit is associated with stdlib.h.

The -g flag tells the computer to emit extra information for use by a debugger.

Section 4:
The debugger says that there was a segmentation fault at line 7 of test.c.
This might be because the buffer has not been allocated memory before
using it to create a copy of a string.